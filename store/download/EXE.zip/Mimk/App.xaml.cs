using System.Windows;

namespace MiniWord
{
    public partial class App : Application
    {
    }
}
