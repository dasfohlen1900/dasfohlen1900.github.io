using System;
using System.IO;
using System.IO.Compression;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using Microsoft.Win32;

namespace MiniWord
{
    public partial class MainWindow : Window
    {
        private string currentFile = "";
        private bool isDirty = false;
        private RichTextBox richTextBox = new RichTextBox
        {
            VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
            Margin = new Thickness(10)
        };
        private string selectedFont = "Segoe UI";

        public MainWindow()
        {
            InitializeComponent();
            InitUI();
            this.PreviewKeyDown += MainWindow_PreviewKeyDown;
            richTextBox.TextChanged += (s, e) => isDirty = true;
        }

        private void InitUI()
        {
            TabControl ribbon = new TabControl();
            ribbon.Items.Add(CreateTab("Datei", DateiTab()));
            ribbon.Items.Add(CreateTab("Start", StartTab()));
            ribbon.Items.Add(CreateTab("Einfügen", InsertTab()));
            ribbon.Items.Add(CreateTab("Zeichnen", DrawTab()));
            ribbon.Items.Add(CreateTab("Ansicht", ViewTab()));
            ribbon.Items.Add(CreateTab("Überprüfen", ReviewTab()));

            Grid grid = new Grid();
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            grid.RowDefinitions.Add(new RowDefinition());
            grid.Children.Add(ribbon);
            Grid.SetRow(richTextBox, 1);
            grid.Children.Add(richTextBox);

            this.Content = grid;
        }

        private TabItem CreateTab(string header, StackPanel panel)
        {
            return new TabItem { Header = header, Content = panel };
        }

        private StackPanel DateiTab()
        {
            var panel = new StackPanel { Orientation = Orientation.Horizontal };
            Button btnNew = new Button { Content = "Neu" }; btnNew.Click += (s, e) => NewDocument(); panel.Children.Add(btnNew);
            Button btnOpen = new Button { Content = "Öffnen" }; btnOpen.Click += (s, e) => OpenFile(); panel.Children.Add(btnOpen);
            Button btnSave = new Button { Content = "Speichern" }; btnSave.Click += (s, e) => SaveFile(); panel.Children.Add(btnSave);
            return panel;
        }

        private StackPanel StartTab()
        {
            var panel = new StackPanel { Orientation = Orientation.Horizontal };
            Button btnBold = new Button { Content = "Fett" }; btnBold.Click += (s, e) => ToggleBold(); panel.Children.Add(btnBold);
            Button btnItalic = new Button { Content = "Kursiv" }; btnItalic.Click += (s, e) => ToggleItalic(); panel.Children.Add(btnItalic);
            Button btnUnderline = new Button { Content = "Unterstrichen" }; btnUnderline.Click += (s, e) => ToggleUnderline(); panel.Children.Add(btnUnderline);
            Button btnNumbering = new Button { Content = "Nummerierung" }; btnNumbering.Click += (s, e) => ApplyNumbering(); panel.Children.Add(btnNumbering);
            Button btnBullets = new Button { Content = "Aufzählung" }; btnBullets.Click += (s, e) => ApplyBullets(); panel.Children.Add(btnBullets);
            Button btnFont = new Button { Content = "Schriftart" }; btnFont.Click += (s, e) => ChooseFont(); panel.Children.Add(btnFont);
            Button btnColor = new Button { Content = "Farbe" }; btnColor.Click += (s, e) => ChooseColor(); panel.Children.Add(btnColor);
            Button btnCharTable = new Button { Content = "Zeichentabelle" }; btnCharTable.Click += (s, e) => OpenCharacterTable(); panel.Children.Add(btnCharTable);
            return panel;
        }

        private StackPanel InsertTab()
        {
            var panel = new StackPanel { Orientation = Orientation.Horizontal };
            Button btnImage = new Button { Content = "Bild einfügen" }; btnImage.Click += (s, e) => InsertImage(); panel.Children.Add(btnImage);
            Button btnTable = new Button { Content = "Tabelle einfügen" }; btnTable.Click += (s, e) => InsertTable(); panel.Children.Add(btnTable);
            return panel;
        }

        private StackPanel DrawTab()
        {
            var panel = new StackPanel { Orientation = Orientation.Horizontal };
            Button btnRect = new Button { Content = "Rechteck" }; btnRect.Click += (s, e) => InsertShape("Rectangle"); panel.Children.Add(btnRect);
            Button btnEllipse = new Button { Content = "Ellipse" }; btnEllipse.Click += (s, e) => InsertShape("Ellipse"); panel.Children.Add(btnEllipse);
            Button btnLine = new Button { Content = "Linie" }; btnLine.Click += (s, e) => InsertShape("Line"); panel.Children.Add(btnLine);
            return panel;
        }

        private StackPanel ViewTab() { return new StackPanel(); }
        private StackPanel ReviewTab() { return new StackPanel(); }

        // --- Text Formatierung ---
        private void ToggleBold()
        {
            if (richTextBox.Selection.GetPropertyValue(TextElement.FontWeightProperty).Equals(FontWeights.Bold))
                richTextBox.Selection.ApplyPropertyValue(TextElement.FontWeightProperty, FontWeights.Normal);
            else
                richTextBox.Selection.ApplyPropertyValue(TextElement.FontWeightProperty, FontWeights.Bold);
        }

        private void ToggleItalic()
        {
            if (richTextBox.Selection.GetPropertyValue(TextElement.FontStyleProperty).Equals(FontStyles.Italic))
                richTextBox.Selection.ApplyPropertyValue(TextElement.FontStyleProperty, FontStyles.Normal);
            else
                richTextBox.Selection.ApplyPropertyValue(TextElement.FontStyleProperty, FontStyles.Italic);
        }

        private void ToggleUnderline()
        {
            TextDecorationCollection decorations = richTextBox.Selection.GetPropertyValue(Inline.TextDecorationsProperty) as TextDecorationCollection;
            if (decorations == TextDecorations.Underline)
                richTextBox.Selection.ApplyPropertyValue(Inline.TextDecorationsProperty, null);
            else
                richTextBox.Selection.ApplyPropertyValue(Inline.TextDecorationsProperty, TextDecorations.Underline);
        }

        private void ApplyNumbering()
        {
            List list = new List { MarkerStyle = TextMarkerStyle.Decimal };
            list.ListItems.Add(new ListItem(new Paragraph(new Run(richTextBox.Selection.Text))));
            richTextBox.Selection.Text = "";
            richTextBox.Document.Blocks.Add(list);
        }

        private void ApplyBullets()
        {
            List list = new List { MarkerStyle = TextMarkerStyle.Disc };
            list.ListItems.Add(new ListItem(new Paragraph(new Run(richTextBox.Selection.Text))));
            richTextBox.Selection.Text = "";
            richTextBox.Document.Blocks.Add(list);
        }

        private void ChooseFont()
        {
            var dlg = new System.Windows.Forms.FontDialog();
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                selectedFont = dlg.Font.Name;
                richTextBox.Selection.ApplyPropertyValue(TextElement.FontFamilyProperty, new FontFamily(selectedFont));
            }
        }

        private void ChooseColor()
        {
            var dlg = new System.Windows.Forms.ColorDialog();
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                Color wpfColor = Color.FromArgb(dlg.Color.A, dlg.Color.R, dlg.Color.G, dlg.Color.B);
                richTextBox.Selection.ApplyPropertyValue(TextElement.ForegroundProperty, new SolidColorBrush(wpfColor));
            }
        }

        // --- Bilder, Tabellen, Shapes ---
        private void InsertImage()
        {
            OpenFileDialog dlg = new OpenFileDialog { Filter = "Bilder|*.png;*.jpg;*.jpeg;*.bmp;*.gif" };
            if (dlg.ShowDialog() == true)
            {
                var bitmap = new System.Windows.Media.Imaging.BitmapImage(new Uri(dlg.FileName));
                Image img = new Image { Source = bitmap, Width = 200 };
                new InlineUIContainer(img, richTextBox.CaretPosition);
            }
        }

        private void InsertTable(int rows = 2, int columns = 2)
        {
            Table table = new Table { CellSpacing = 2, BorderThickness = new Thickness(1), BorderBrush = Brushes.Black };
            for (int c = 0; c < columns; c++) table.Columns.Add(new TableColumn());
            TableRowGroup trg = new TableRowGroup();
            for (int r = 0; r < rows; r++)
            {
                TableRow row = new TableRow();
                for (int c = 0; c < columns; c++)
                {
                    TableCell cell = new TableCell(new Paragraph(new Run("")));
                    cell.BorderBrush = Brushes.Black;
                    cell.BorderThickness = new Thickness(0.5);
                    row.Cells.Add(cell);
                }
                trg.Rows.Add(row);
            }
            table.RowGroups.Add(trg);
            richTextBox.Document.Blocks.Add(table);
        }

        private void InsertShape(string type)
        {
            UIElement shape = null;
            switch (type)
            {
                case "Line":
                    shape = new System.Windows.Shapes.Line { X1 = 0, Y1 = 0, X2 = 100, Y2 = 0, Stroke = Brushes.Black, StrokeThickness = 2 };
                    break;
                case "Rectangle":
                    shape = new System.Windows.Shapes.Rectangle { Width = 100, Height = 50, Stroke = Brushes.Black, StrokeThickness = 2 };
                    break;
                case "Ellipse":
                    shape = new System.Windows.Shapes.Ellipse { Width = 50, Height = 50, Stroke = Brushes.Black, StrokeThickness = 2 };
                    break;
            }
            if (shape != null)
            {
                new InlineUIContainer(shape, richTextBox.CaretPosition);
            }
        }

        // --- Zeichentabelle ---
        private void OpenCharacterTable()
        {
            Window charWindow = new Window { Title = "Zeichentabelle", Width = 300, Height = 400 };
            WrapPanel panel = new WrapPanel(); FontFamily font = new FontFamily(selectedFont);
            for (char c = (char)32; c < 256; c++)
            {
                Button btn = new Button { Content = c.ToString(), FontFamily = font, Width = 30, Height = 30, Margin = new Thickness(2) };
                btn.Click += (s, e) => richTextBox.CaretPosition.InsertTextInRun(c.ToString());
                panel.Children.Add(btn);
            }
            charWindow.Content = new ScrollViewer { Content = panel };
            charWindow.Show();
        }

        // --- Dokumentenmanagement ---
        private void NewDocument()
        {
            if (isDirty) PromptSave();
            richTextBox.Document = new FlowDocument();
            currentFile = "";
            isDirty = false;
        }

        private void SaveFile()
        {
            if (string.IsNullOrEmpty(currentFile))
            {
                SaveFileDialog dlg = new SaveFileDialog { Filter = "MiniWord Dokument (*.mwdd)|*.mwdd" };
                if (dlg.ShowDialog() == true)
                {
                    currentFile = dlg.FileName;
                }
                else return;
            }
            TextRange range = new TextRange(richTextBox.Document.ContentStart, richTextBox.Document.ContentEnd);
            using (MemoryStream ms = new MemoryStream())
            {
                range.Save(ms, DataFormats.Rtf);
                using (FileStream fs = new FileStream(currentFile, FileMode.Create))
                using (ZipArchive zip = new ZipArchive(fs, ZipArchiveMode.Create))
                {
                    ZipArchiveEntry entry = zip.CreateEntry("content.rtf");
                    using (var entryStream = entry.Open()) ms.WriteTo(entryStream);
                }
            }
            isDirty = false;
        }

        private void OpenFile()
        {
            OpenFileDialog dlg = new OpenFileDialog { Filter = "MiniWord Dokument (*.mwdd)|*.mwdd" };
            if (dlg.ShowDialog() == true)
            {
                currentFile = dlg.FileName;
                OpenFile(currentFile);
            }
        }

        public void OpenFile(string path)
        {
            using (FileStream fs = new FileStream(path, FileMode.Open))
            using (ZipArchive zip = new ZipArchive(fs, ZipArchiveMode.Read))
            {
                var entry = zip.GetEntry("content.rtf");
                using (var entryStream = entry.Open())
                {
                    TextRange range = new TextRange(richTextBox.Document.ContentStart, richTextBox.Document.ContentEnd);
                    range.Load(entryStream, DataFormats.Rtf);
                }
            }
            isDirty = false;
        }

        private void PromptSave()
        {
            var result = MessageBox.Show("Möchten Sie die Änderungen speichern?", "Mini-Word", MessageBoxButton.YesNoCancel, MessageBoxImage.Warning);
            if (result == MessageBoxResult.Yes) SaveFile();
            else if (result == MessageBoxResult.Cancel) throw new OperationCanceledException();
        }

        protected override void OnClosing(System.ComponentModel.CancelEventArgs e)
        {
            if (isDirty)
            {
                try { PromptSave(); }
                catch { e.Cancel = true; return; }
            }
            base.OnClosing(e);
        }

        // --- Shortcuts ---
        private void MainWindow_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (Keyboard.Modifiers == ModifierKeys.Control)
            {
                switch (e.Key)
                {
                    case Key.A: richTextBox.SelectAll(); e.Handled = true; break;
                    case Key.B: ToggleBold(); e.Handled = true; break;
                    case Key.C: richTextBox.Copy(); e.Handled = true; break;
                    case Key.V: richTextBox.Paste(); e.Handled = true; break;
                    case Key.X: richTextBox.Cut(); e.Handled = true; break;
                    case Key.S: SaveFile(); e.Handled = true; break;
                    case Key.O: OpenFile(); e.Handled = true; break;
                    case Key.N: NewDocument(); e.Handled = true; break;
                    case Key.D: ApplyNumbering(); e.Handled = true; break;
                    case Key.E: ApplyAlignment(TextAlignment.Center); e.Handled = true; break;
                    case Key.L: ApplyAlignment(TextAlignment.Left); e.Handled = true; break;
                    case Key.R: ApplyAlignment(TextAlignment.Right); e.Handled = true; break;
                    case Key.J: ApplyAlignment(TextAlignment.Justify); e.Handled = true; break;
                }
            }
            else if (Keyboard.Modifiers == (ModifierKeys.Control | ModifierKeys.Shift))
            {
                switch (e.Key)
                {
                    case Key.A: richTextBox.Selection.Select(richTextBox.Document.ContentStart, richTextBox.Document.ContentEnd); e.Handled = true; break;
                    case Key.K: ChooseFont(); e.Handled = true; break;
                    case Key.D: ExportPDF(); e.Handled = true; break;
                    case Key.E: ExportOctxt(); e.Handled = true; break;
                    case Key.S: SaveAs(); e.Handled = true; break;
                }
            }
            else if (e.Key == Key.F4) SpellCheck();
            else if (e.Key == Key.F11) ToggleFullscreen();
        }

        // --- Dummy-Methoden für Shortcuts ---
        private void ApplyAlignment(TextAlignment align) { richTextBox.Selection.ApplyPropertyValue(Paragraph.TextAlignmentProperty, align); }
        private void SpellCheck() { MessageBox.Show("Rechtschreibprüfung noch nicht implementiert"); }
        private void ToggleFullscreen() { this.WindowState = this.WindowState == WindowState.Maximized ? WindowState.Normal : WindowState.Maximized; }
        private void ExportPDF() { MessageBox.Show("Export als PDF noch nicht implementiert"); }
        private void ExportOctxt()
        {
            SaveFileDialog dlg = new SaveFileDialog
            {
                Filter = "MiniWord Text Export (*.octxt)|*.octxt",
                FileName = System.IO.Path.GetFileNameWithoutExtension(currentFile) + ".octxt"
            };
            if (dlg.ShowDialog() == true)
            {
                TextRange range = new TextRange(richTextBox.Document.ContentStart, richTextBox.Document.ContentEnd);
                File.WriteAllText(dlg.FileName, range.Text);
                MessageBox.Show("Export abgeschlossen!", "MiniWord", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void SaveAs()
        {
            SaveFileDialog dlg = new SaveFileDialog
            {
                Filter = "MiniWord Dokument (*.mwdd)|*.mwdd",
                FileName = System.IO.Path.GetFileName(currentFile)
            };
            if (dlg.ShowDialog() == true)
            {
                currentFile = dlg.FileName;
                SaveFile();
            }
        }
    }
}
